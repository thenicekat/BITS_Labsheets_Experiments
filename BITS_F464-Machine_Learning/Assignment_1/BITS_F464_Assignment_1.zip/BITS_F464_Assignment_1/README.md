# BITS_F464_Assignment_1
This repository has been made for Machine Learning Assignment 1

Implemented Perceptron, Fisher's Linear Discriminant Analysis and Logistic Regression from scratch without using any ML libraries such as scikit-learn or seaborn. Made models which predicted if the person's cancer is benign or malignant based on the dataset given 

Members:
Divyateja Pasupuleti 2021A7PS0075H
Kumarasamy Chelliah 2021A7PS0096H
Adarsh Das 2021A7PS1511H